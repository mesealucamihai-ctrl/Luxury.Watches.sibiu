// Script JS simplu pentru site
